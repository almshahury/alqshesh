import React from "react";

export default function AdminUsers() {
  return (
    <div className="container mx-auto px-4 py-6">
      <h2 className="text-2xl font-bold mb-4">إدارة المستخدمين</h2>
      <p>هنا قائمة بالمستخدمين المسجلين في موقع القشيشي.</p>
    </div>
  );
}
