import React from "react";

export default function AdminOrders() {
  return (
    <div className="container mx-auto px-4 py-6">
      <h2 className="text-2xl font-bold mb-4">إدارة الطلبات</h2>
      <p>هنا تظهر جميع الطلبات التي تم تقديمها من العملاء.</p>
    </div>
  );
}
